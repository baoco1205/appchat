# Chat Widget

A Pen created on CodePen.io. Original URL: [https://codepen.io/drehimself/pen/KdXwxR](https://codepen.io/drehimself/pen/KdXwxR).

Based on this dribbble shot: https://dribbble.com/shots/1818748-Appon-Chat-Widget. Search field is functional. You can also add your own messages to the chat window! A random response will be given :)